from flask import Flask, render_template,request
from scrapper import FaceBookBot
from detection_model import detection
app = Flask(__name__)

@app.route("/",methods = ['GET'])
def home():
    return render_template('user_page.html')


@app.route("/send_data", methods = ['POST'])
def user():
    url = request.form['postID']
    #print(postID)
    scrapper_obj = FaceBookBot()
    final = scrapper_obj.post_content("4948996235154195",url)
    #print(final)
    detection_obj = detection()
    detection.profanity(final)
    return render_template('result_page.html', result="Wheeeee!")
    
# @app.route("/result")
# def result():
#     user_obj = user()
#     print(user_obj.url)
#     return render_template('result_page.html', result="Wheeeee!")


if __name__ == '__main__':
    app.run(debug=True)